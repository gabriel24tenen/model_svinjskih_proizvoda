#pragma once
#include <iostream>
#include <cstring>
#include <string>
#include <cstdlib>

using namespace std;

class Adresa {
private:
	string grad_opcina;
	string zupanija;
	unsigned short broj;
	string ulica;
	int postanski_broj;
	bool RH(string cro);
	int kontrola_pbr(int pbr);
	string adress;
public:
	void set_grad_opcina(string new_grad_opcina);
	void set_zupanija(string new_zupanija);
	void set_broj(unsigned short new_broj);
	void set_postanskibroj(int new_postanski_broj);
	void set_ulica(string new_ulica);
	string get_grad_opcina();
	string get_zupanija();
	string get_broj();
	string get_postanski_broj();
	string get_ulica();
	string get_adresa();
	void set_adresa(const string new_ulica, unsigned short new_broj, const string new_grad_opcina, const string new_zupanija, int new_postanski_broj);
};