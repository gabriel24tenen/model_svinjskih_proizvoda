#pragma once
#include "Osoba.h"
#include "Vrsta_obrta.h"
#include "Poduzece.h"

using namespace std;

class Poduzece;
class Obrtnik : public Osoba {
	private:
		string naziv_obrta;
		Vrsta_obrta vrsta_obrta;
		Adresa adresa_obrta;
		Poduzece *poduzece;
	public:
		string get_adresa_obrta();
		string get_vrsta_obrta();
		string get_naziv_obrta();
		void set_adresa_obrta(const string new_ulica, unsigned short new_broj, const string new_grad_opcina, const string new_zupanija, int new_postanski_broj);
		void set_vrsta_obrta(unsigned short new_vrsta_obrta);
		void set_naziv_obrta(string new_naziv_obrta);
		void napravi_narudzbu();
};