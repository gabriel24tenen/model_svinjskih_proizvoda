#include "Svinjar.h"

void Svinjar::ciscenje(string danas, Datum datum_ciscenja)
{
	Datum datum;
	datum.set_datum(danas);
	unsigned short dan = stoi(danas.substr(0, 2));
	unsigned short mjesec = stoi(danas.substr(3, 2));
	unsigned short godina = stoi(danas.substr(6, 4));
	string ciscenje = datum_ciscenja.get_datum();
	unsigned short ciscenje_dan = stoi(ciscenje.substr(0, 2));
	unsigned short ciscenje_mjesec = stoi(ciscenje.substr(3, 2));
	unsigned short ciscenje_godina = stoi(ciscenje.substr(6, 4));
	if (ciscenje_godina > godina || (ciscenje_godina == godina && ciscenje_mjesec > mjesec) || (ciscenje_godina == godina && ciscenje_mjesec == mjesec && ciscenje_dan > dan))
	{
		cout << "Ciscenje svinjara je zakazano za drugi datum" << endl;
		cout << "Datum ciscenja: " << ciscenje_dan << ". " << ciscenje_mjesec << ". " << ciscenje_godina;
	}
	else if (ciscenje_godina == godina && ciscenje_mjesec == mjesec && ciscenje_dan == dan)
		cout << "Termin ciscenja svinjara je danas! " << endl;
	else cout << "Termin ciscenja svinjara je prosao!" << endl;
}

unsigned int Svinjar::get_velicina()
{
	return velicina;
}

unsigned short Svinjar::get_kapacitet()
{
	return kapacitet;
}

string Svinjar::get_adresa_svinjara()
{
	return adresa_svinjara.get_adresa();
}

string Svinjar::get_datum_ciscenja()
{
	return datum_ciscenja.get_datum();
}

string Svinjar::get_datum_izgradnje()
{
	return datum_izgradnje.get_datum();
}

void Svinjar::set_velicina(unsigned int new_velicina)
{
	velicina = new_velicina;
}

void Svinjar::set_kapacitet(unsigned short new_kapacitet)
{
	kapacitet = new_kapacitet;
}

void Svinjar::set_adresa_svinjara(const string new_ulica, unsigned short new_broj, const string new_grad_opcina, const string new_zupanija, int new_postanski_broj)
{
	adresa_svinjara.set_adresa(new_ulica, new_broj, new_grad_opcina, new_zupanija, new_postanski_broj);
}

void Svinjar::set_datum_izgradnje(string new_datum_izgradnje)
{
	datum_izgradnje.set_datum(new_datum_izgradnje);
}

void Svinjar::set_datum_ciscenja(string new_datum_ciscenja)
{
	datum_ciscenja.set_datum(new_datum_ciscenja);
}

Svinjar::Svinjar(const unsigned short kapacitet, const unsigned short velicina, const Datum datum_izgradnje, const Datum datum_ciscenja, const Adresa adresa_svinjara)
	: kapacitet(kapacitet), velicina(velicina), datum_izgradnje(datum_izgradnje), datum_ciscenja(datum_ciscenja), adresa_svinjara(adresa_svinjara) {}

list <Svinja*> Svinjar::get_svinje()
{
	return svinje_svinjar;
}

void Svinjar::dodaj_svinju_svinjar(Svinja* svinja, Svinjar* svinjar)
{
	if (svinje_svinjar.size() == svinjar->kapacitet)
	{
		cout << "Kapacitet svinjara je napunjen! " << endl;
		exit(EXIT_FAILURE);
	}
	svinje_svinjar.push_back(svinja);
	svinja->set_svinjar(this);
}
