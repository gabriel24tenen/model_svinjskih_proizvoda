#pragma once
#include <list>
#include <fstream>
#include "Radnik.h"

using namespace std;

class Radnik;
class Radnici {
private:
	list <Radnik> svi_radnici;
public:
	Radnik* get_radnik(unsigned int i);
	void set_radnik(Radnik new_radnik);
	void import_radnici(const char* popis_radnika);
	void export_radnici(const char* popis_radnika);
	list <Radnik>& lista_radnika();
};