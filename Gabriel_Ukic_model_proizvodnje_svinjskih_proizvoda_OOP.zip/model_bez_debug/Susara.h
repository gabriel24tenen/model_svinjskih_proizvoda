#pragma once
#include <iostream>
#include <list>
#include <string>
#include <cstring>
#include "Adresa.h"
#include "Proizvod.h"
#include "Skladiste.h"

using namespace std;

class Susara {
private:
	Adresa adresa_susare;
	int kapacitet;
	Proizvod* proizvod;
	Skladiste* skladiste;
	list <Proizvod*> suseni_proizvodi;
public:
	std::string get_adresa_susare();
	std::string get_kapacitet();
	void set_adresa_susare(const string new_ulica, unsigned short new_broj, const string new_grad_opcina, const string new_zupanija, int new_postanski_broj);
	void set_kapacitet(int new_kapacitet);
	void potreba_susenja(Proizvod* proizvod);
};