#pragma once
#pragma warning (disable : 4996)
#include <iostream>
#include <cstring>
#include <string>
#include <ctime>
#include <cstdlib>
#define _CRT_SECURE_NO_WARNINGS
using namespace std;
class Datum {
	private:
		unsigned short dan;
		unsigned short mjesec;
		unsigned short godina;
		bool kontrola(string str);
	public:
		void set_datum(string new_datum);
		string get_datum();
		unsigned short broj_godina();
};