#pragma once
#include "Osoba.h"
#include "Vrsta_hrane.h"

using namespace std;

class Dobavljac : public Osoba {
	private:
		Vrsta_hrane vrsta_hrane;
		int kolicina;
	public:
		string get_vrsta_hrane();
		string get_kolicina();
		void set_vrsta_hrane(unsigned short new_vrsta_hrane);
		void set_kolicina(int new_kolicina);
};