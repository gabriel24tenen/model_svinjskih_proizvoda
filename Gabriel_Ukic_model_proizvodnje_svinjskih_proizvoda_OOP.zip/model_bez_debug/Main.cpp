#pragma once
#include <iostream>
#include <cstring>
#include <string>
#include <ctime>
#include <cstdlib>
#include "Osoba.h"
#include "Svinja.h"
#include "Poduzece.h"
#include "Radnik.h"
#include "Dobavljac.h"
#include "Vlasnik.h"
#include "Skladiste.h"
#include "Susara.h"

using namespace std;
int izbornik() {
	cout << "----------------------IZBORNIK----------------------" << endl;
	cout << "1- narudzba iz perspektive obrtnika" << endl;
	cout << "2- unos novog radnika i ispis svih placa" << endl;
	cout << "3- dodavanje svinje u svinjar" << endl;
	cout << "4- dodavanje svinje u poduzece" << endl;
	cout << "5- unos svinje i provjera namjene svinje za procesurianje" << endl;
	cout << "6- unos proizvoda i potreba susenja" << endl;
	cout << "7- unos dobavljaca i naru�ivanje hrane" << endl;
	cout << "9- izlaz iz programa" << endl;
	cout << "Vas unos: " << endl;
	int izbor;
	cin >> izbor;
	return izbor;
}


int main() {
	Vlasnik* novi_vlasnik = new Vlasnik;
	Datum datum_radnik{};
	Radno_mjesto radno_mjesto;
	float satnica{};
	int broj_sati{};
	int velicina_svinjar;
	unsigned short kapacitet_svinjar;
	Datum izgradnja_svinjar, ciscenje_svinjar, trenutni_datum;
	/*proizvodi*/
	Proizvod* novi_proizvod = new Proizvod;
	Proizvod* drugi_proizvod = new Proizvod;
	Svinjar* svinjar = new Svinjar(0, 0, Datum{}, Datum{}, Adresa{});
	/*inicijalizacija radnika*/
	Radnik radnik_prvi(datum_radnik, radno_mjesto, satnica, broj_sati);
	Radnik radnik_drugi(datum_radnik, radno_mjesto, satnica, broj_sati);
	Radnik radnik_treci(datum_radnik, radno_mjesto, satnica, broj_sati);
	Radnik radnik_novi(datum_radnik, radno_mjesto, satnica, broj_sati);
	Radnici* skup_radnici = new Radnici;
	radnik_prvi.set_datum_zaposlenja("22.05.2022");
	radnik_prvi.set_mjesto_rada(2);
	radnik_prvi.set_satnica(8.95);
	radnik_prvi.set_broj_sati(168);
	radnik_prvi.set_ime("Ante");
	radnik_prvi.set_prezime("Vukic");

	radnik_drugi.set_datum_zaposlenja("24.09.2023");
	radnik_drugi.set_mjesto_rada(1);
	radnik_drugi.set_satnica(9.8);
	radnik_drugi.set_broj_sati(160);
	radnik_drugi.set_ime("Stipe");
	radnik_drugi.set_prezime("Franic");

	radnik_treci.set_datum_zaposlenja("10.10.2022");
	radnik_treci.set_mjesto_rada(4);
	radnik_treci.set_satnica(9.25);
	radnik_treci.set_broj_sati(164);
	radnik_treci.set_ime("Ivan");
	radnik_treci.set_prezime("Jurlov");

	skup_radnici->set_radnik(radnik_prvi);
	skup_radnici->set_radnik(radnik_drugi);
	skup_radnici->set_radnik(radnik_treci);
	/*incijalizacija vlasnika*/
	novi_vlasnik->set_ime("Mario");
	novi_vlasnik->set_prezime("Dragic");
	novi_vlasnik->set_datum_vlasnistva("14.06.2017");
	/*inicijalizacija poduzeca*/
	Vrsta_poduzeca vrsta;
	string ime;
	string place;
	Poduzece mesnica_Zagora(ime, vrsta, novi_vlasnik, radnik_prvi, skup_radnici);
	mesnica_Zagora.set_ime_poduzeca("Mesnica Zagora");
	mesnica_Zagora.set_vrsta_poduzeca(0);
	mesnica_Zagora.dodaj_vlasnika(novi_vlasnik);
	mesnica_Zagora.dodaj_radnika("Ante Vukic");
	mesnica_Zagora.dodaj_radnika("Stipe Franic");
	mesnica_Zagora.dodaj_radnika("Ivan Jurlov");
	/*svinje*/
	Svinja* nova_svinja = new Svinja;
	Svinja* druga_svinja = new Svinja;
	nova_svinja->set_ID("123456");
	nova_svinja->set_kilaza(68.7);
	nova_svinja->set_vrsta("Jorksirska svinja");
	nova_svinja->set_datum_zaprimanja("14.02.2024");
	nova_svinja->set_ciljana_kilaza(202);
	nova_svinja->set_planirani_datum_klanja("23.12.2024");
	nova_svinja->set_namjena(2);
	druga_svinja->set_ID("564851");
	druga_svinja->set_kilaza(60.25);
	druga_svinja->set_vrsta("Turopoljska svinja");
	druga_svinja->set_datum_zaprimanja("28.05.2024");
	druga_svinja->set_ciljana_kilaza(250);
	druga_svinja->set_planirani_datum_klanja("16.12.2024");
	druga_svinja->set_namjena(3);
	int i = 0;
	do {
		i = izbornik();
		switch (i)
		{
			case 1:
			{
				mesnica_Zagora.narudzba();
				break;
			}
			case 2:
			{
				int a, c;
				double b;
				string d, i, p;
				cout << "Ime: ";
				cin >> i;
				cout << "Prezime: ";
				cin >> p;
				cout << "Mjesto rada(0-hranitelj, 1-koljac, 2-susar, 3-skladistar, 4-distributer): ";
				cin >> a;
				cout << "Satnica: ";
				cin >> b;
				cout << "Broj sati: ";
				cin >> c;
				cout << "Unesite datum zaposlenja: ";
				cin >> d;
				radnik_novi.set_broj_sati(c);
				radnik_novi.set_mjesto_rada(a);
				radnik_novi.set_satnica(b);
				radnik_novi.set_ime(i);
				radnik_novi.set_prezime(p);
				radnik_novi.set_datum_zaposlenja(d);
				skup_radnici->set_radnik(radnik_novi);
				mesnica_Zagora.ispis_svih_placa();
				break;
			}
			case 3:
			{
				string izg, cisc, tren;
				cout << "Unesite kapacitet svinjara: ";
				cin >> kapacitet_svinjar;
				cout << "Unesite velicinu svinjara(u metrima kvadratnim): ";
				cin >> velicina_svinjar;
				cout << "Unesite datum izgradnje: ";
				cin >> izg;
				izgradnja_svinjar.set_datum(izg);
				cout << "Unesite planirani datum ciscenja: ";
				cin >> cisc;
				ciscenje_svinjar.set_datum(cisc);
				Svinjar* svinjar_metoda = new Svinjar(kapacitet_svinjar, velicina_svinjar, izgradnja_svinjar, ciscenje_svinjar, Adresa{});
				svinjar->dodaj_svinju_svinjar(nova_svinja, svinjar_metoda);
				cout << "Uspjesno dodana svinja u svinjar" << endl;
				cout << "Kapacitet unesenog svinjara: " << svinjar_metoda->get_kapacitet() << endl;
				cout << "Velicina svinjara: " << svinjar_metoda->get_velicina() << " kvadratnih metara" << endl;
				cout << "Datum izgradnje: " << svinjar_metoda->get_datum_izgradnje() << endl;
				cout << "Unesite trenutni datum: ";
				cin >> tren;
				svinjar_metoda->ciscenje(tren, ciscenje_svinjar);
				delete svinjar_metoda;
				break;
			}
			case 4: 
			{
				Datum klanje;
				string id_unos, datum_unos, klanje_unos, vrsta_unos, trenutni_datum;
				float kilaza_unos, ciljana_kilaza_unos;
				unsigned short namjena_unos;
				Svinja* unos_svinje = new Svinja;
				cout << "ID: "; cin >> id_unos; cout << "Vrsta svinje: "; cin >>vrsta_unos; cout << "Datum zaprimanja: "; cin >> datum_unos; cout << "Kilaza: "; cin >> kilaza_unos; cout << "Ciljana kilaza: "; cin >> ciljana_kilaza_unos;
				cout << "Namjena svinje (0-mesnica, 1-odojak, 2-proizvodnja, 3-prodaja, 4-uzgoj): "; cin >> namjena_unos; cout << "Planirani datum klanja: "; cin >> klanje_unos;
				unos_svinje->set_ID(id_unos); unos_svinje->set_datum_zaprimanja(datum_unos); unos_svinje->set_kilaza(kilaza_unos); unos_svinje->set_ciljana_kilaza(ciljana_kilaza_unos); unos_svinje->set_namjena(namjena_unos); unos_svinje->set_planirani_datum_klanja(klanje_unos); unos_svinje->set_vrsta(vrsta_unos);
				mesnica_Zagora.dodaj_Svinju(unos_svinje);
				cout << "\n-------------PRIJAVA NOVE SVINJE-------------" << endl; cout << "ID: " << unos_svinje->get_ID() << " Datum zaprimanja " << unos_svinje->get_datum_zaprimanja() << " Vrsta svinje: " << unos_svinje->get_vrsta() << endl;
				cout << "Kilaza: " << unos_svinje->get_kilaza() << " Ciljana kilaza: " << unos_svinje->get_ciljana_kilaza() << endl;
				cout << "Namjena: " << unos_svinje->get_namjena() << " Planirani datum klanja: " << unos_svinje->get_planirani_datum_klanja() << endl;
				cout << "\nOstale prijavljene svinje: " << endl;
				mesnica_Zagora.dodaj_Svinju(nova_svinja);
				cout << "\nID: " << nova_svinja->get_ID() << " Vrsta svinje: " << nova_svinja->get_vrsta() <<" Datum zaprimanja " << nova_svinja->get_datum_zaprimanja() << endl;
				cout << "Kilaza: " << nova_svinja->get_kilaza() << " Ciljana kilaza: " << nova_svinja->get_ciljana_kilaza() << endl;
				cout << "Namjena: " << nova_svinja->get_namjena() <<" Planirani datum klanja: " << nova_svinja->get_planirani_datum_klanja() << endl;
				mesnica_Zagora.dodaj_Svinju(druga_svinja);
				cout << "\n\nID: " << druga_svinja->get_ID() << " Vrsta svinje: "<< druga_svinja->get_vrsta() << " Datum zaprimanja " << druga_svinja->get_datum_zaprimanja() << endl;
				cout << "Kilaza: " << druga_svinja->get_kilaza() << " Ciljana kilaza: " << druga_svinja->get_ciljana_kilaza() << endl;
				cout << "Namjena: " << druga_svinja->get_namjena() << " Planirani datum klanja: " << druga_svinja->get_planirani_datum_klanja() << endl;
				cout << "\n\n\n\n";
				klanje.set_datum(klanje_unos);
				cout << "Unesite trenutni datum: ";
				cin >> trenutni_datum;
				unos_svinje->klanje(trenutni_datum, klanje);
				delete unos_svinje;
				break;
			}
			case 5:
			{ 
				string id_unos, datum_unos, klanje_unos, vrsta_unos, trenutni_datum;
				float kilaza_unos, ciljana_kilaza_unos;
				unsigned short namjena_unos;
				Svinja* svinja_namjena = new Svinja;
				cout << "ID: "; cin >> id_unos; cout << "Vrsta svinje: "; cin >> vrsta_unos; cout << "Datum zaprimanja: "; cin >> datum_unos; cout << "Kilaza: "; cin >> kilaza_unos; cout << "Ciljana kilaza: "; cin >> ciljana_kilaza_unos;
				cout << "Namjena svinje (0-mesnica, 1-odojak, 2-proizvodnja, 3-prodaja, 4-uzgoj): "; cin >> namjena_unos; cout << "Planirani datum klanja: "; cin >> klanje_unos;
				svinja_namjena->set_ID(id_unos); svinja_namjena->set_datum_zaprimanja(datum_unos); svinja_namjena->set_kilaza(kilaza_unos); svinja_namjena->set_ciljana_kilaza(ciljana_kilaza_unos); svinja_namjena->set_namjena(namjena_unos); svinja_namjena->set_planirani_datum_klanja(klanje_unos); svinja_namjena->set_vrsta(vrsta_unos);
				Proizvod* proizvod_namjena = new Proizvod;
				proizvod_namjena->kontrola_svinje(svinja_namjena);
				cout << "\nUnesene svinje: \n";
				novi_proizvod->kontrola_svinje(nova_svinja);
				drugi_proizvod->kontrola_svinje(druga_svinja);
				delete svinja_namjena;
				delete proizvod_namjena;
				break;
			}
			case 6:
			{
				Proizvod* proizvod_unos = new Proizvod;
				Skladiste* skladiste_unos = new Skladiste;
				unsigned short vps;
				string polje_unos[11] = { "panceta", "prsut", "plecka", "cvarci", "suseno meso", "kobasice", "pecenica", "lungic", "jetrica", "svinjski organi", "vratina" };
				cout << "Vrste proizvoda: \n";
				for (int i = 0; i < 11; i++) 
				{
					cout << i << " - " << polje_unos[i] << endl;
				}
				cout << "Odabir: ";
				cin >> vps;
				proizvod_unos->set_vrsta_proizvoda(vps);
				Susara* susara_unos = new Susara;
				susara_unos->potreba_susenja(proizvod_unos);
				delete proizvod_unos;
				delete skladiste_unos;
				delete susara_unos;
				break;
			}
			case 7:
			{
				Dobavljac* dobavljac_unos = new Dobavljac;
				Dobavljac vrsta_hrane, kolicina;
				string ime;
				cout << "Unesite ime dobavljaca: ";
				cin >> ime;
				dobavljac_unos->set_ime(ime);
				mesnica_Zagora.dodaj_dobavljaca(dobavljac_unos);
				mesnica_Zagora.narudzba_hrane(vrsta_hrane, kolicina);
				cout << "\nDobavljac: " << dobavljac_unos->get_ime();
				cout << "\nHrana koju ste narucili: " << vrsta_hrane.get_vrsta_hrane();
				cout << "\nKolicina (u kilogramima): " << kolicina.get_kolicina();
				delete dobavljac_unos;
				break;
			}
			case 9:
			{
				cout << "Izlazim iz programa..." << endl;
				break;
			}
			default: 
			{
				cout << "Krivi unos!" << endl;
				break;
			}
		}

	} while (i != 9);

	delete novi_vlasnik;
	delete nova_svinja;
	delete druga_svinja;
	delete novi_proizvod;
	delete drugi_proizvod;
	delete svinjar;
	delete skup_radnici;
	cout << "-------------------------------" << endl;
	return 0;
}