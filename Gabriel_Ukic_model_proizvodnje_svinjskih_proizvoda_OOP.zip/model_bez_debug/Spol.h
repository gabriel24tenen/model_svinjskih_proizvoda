#pragma once
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <string>
using namespace std;
class Spol {
	private:
		const string naziv[4] = { "musko", "zensko", "ostalo", "neizjasnjeno" };
		unsigned short s;
	public:
		string get_naziv();
		unsigned short get_s_no();
		void set_naziv(unsigned short new_s);
};