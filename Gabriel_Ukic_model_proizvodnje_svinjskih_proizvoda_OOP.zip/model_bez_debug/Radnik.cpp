#include "Radnik.h"

string Radnik::get_datum_zaposlenja() {
	return datum_zaposlenja.get_datum();
}

string Radnik::get_mjesto_rada() {
	return mjesto_rada.get_vrsta();
}

string Radnik::get_satnica() {
	return to_string(satnica) + " eura";
}

string Radnik::get_broj_sati() {
	return to_string(broj_sati) + " odradenih sati u mjesecu";
}

void Radnik::set_satnica(float new_satnica) {
	satnica = new_satnica;
}

void Radnik::set_datum_zaposlenja(string new_datum_zaposlenja) {
	datum_zaposlenja.set_datum(new_datum_zaposlenja);
}

void Radnik::set_mjesto_rada(unsigned short new_mjesto_rada) {
	mjesto_rada.set_vrsta(new_mjesto_rada);
}

void Radnik::set_broj_sati(unsigned int new_broj_sati) {
	broj_sati = new_broj_sati;
}

double Radnik::obracun_place() {
	return static_cast<double>(broj_sati) * satnica;
}

void Radnik::ispis_place() {
	cout << "Radnik: " << get_ime() << " " << get_prezime();
	cout << "OIB: " << get_OIB();
	cout << "Datum pocetka radnog odnosa: " << get_datum_zaposlenja();
	cout << "Mjesto rada: " << get_mjesto_rada();
	cout << "Satnica: " << get_satnica();
	cout << "Broj odradenih sati: " << get_broj_sati();
	cout << "Iznos place za ovaj mjesec: " << obracun_place() << " eura";
}