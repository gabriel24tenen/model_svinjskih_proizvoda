#include "Vrsta_poduzeca.h"

unsigned short Vrsta_poduzeca::get_vp_no()
{
	return vp;
}

string Vrsta_poduzeca::get_poduzece()
{
	return poduzece[vp];
}

void Vrsta_poduzeca::set_poduzece(unsigned short new_poduzece)
{
	if (new_poduzece > 3)
	{
		cout << "Pogresno unesena vrsta hrane! " << endl;
		exit(EXIT_FAILURE);
	}
	vp = new_poduzece;
}