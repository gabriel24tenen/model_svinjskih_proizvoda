#include "Skladiste.h"

string Skladiste::get_kapacitet() {
	return to_string(kapacitet) + "jedinica za skladistenje";
}

string Skladiste::get_kapacitet_frizider() {
	return to_string(kapacitet_frizider) + "litara";
}

string Skladiste::get_kapacitet_hladnjaca() {
	return to_string(kapacitet_hladnjaca) + "litara";
}

string Skladiste::get_adresa_skladista() {
	return adresa_skladista.get_adresa();
}

void Skladiste::set_kapacitet(int new_kapacitet) {
	kapacitet = new_kapacitet;
}

void Skladiste::set_kapacitet_frizider(int new_kapacitet_frizider) {
	kapacitet_frizider = new_kapacitet_frizider;
}

void Skladiste::set_kapacitet_hladnjaca(int new_kapacitet_hladnjaca) {
	kapacitet_hladnjaca = new_kapacitet_hladnjaca;
}

void Skladiste::set_adresa_skladista(const string new_ulica, unsigned short new_broj, const string new_grad_opcina, const string new_zupanija, int new_postanski_broj) {
	adresa_skladista.set_adresa(new_ulica, new_broj, new_grad_opcina, new_zupanija, new_postanski_broj);
}

void Skladiste::dodaj_proizvod(Proizvod& proizvod) {
	proizvodi.push_back(proizvod);
}