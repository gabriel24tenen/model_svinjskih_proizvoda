#pragma once
#include <iostream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <vector>
#include <list>
#include <fstream>
#include "Dobavljac.h"
#include "Radnik.h"
#include "Vrsta_poduzeca.h"
#include "Obrtnik.h"
#include "Vlasnik.h"
#include "Svinja.h"
#include "Proizvod.h"

using namespace std;

class Dobavljac;
class Obrtnik;
class Poduzece {
private:
	string ime_poduzeca;
	Vrsta_poduzeca vrsta_poduzeca;
	Vlasnik* vlasnik;
	Radnik &radnik;
	Svinja* svinja;
	/*liste i vektori*/
	vector <Dobavljac*> dobavljaci_poduzeca;
	list <string> radnici_lista;
	vector <Svinja*> svinje;
	list <string> obrtnici;
	
	Radnici* radnici;
public:
	/*standardne metode*/
	string get_ime_poduzeca();
	string get_vrsta_poduzeca();
	void set_ime_poduzeca(string new_ime_poduzeca);
	void set_vrsta_poduzeca(unsigned short new_vrsta_poduzeca);

	/*metode*/
	void dodaj_dobavljaca(Dobavljac* dobavljac);
	void narudzba_hrane(Dobavljac vrsta_hrane, Dobavljac kolicina);
	
	void dodaj_radnika(string new_radnik);
	void ukloni_radnika(string new_radnik);
	void ispis_svih_placa();
	/*Narudzba i obrtnici*/
	void dodaj_obrtnika(string new_obrtnik);
	void ukloni_obrtnika(string new_obrtnik);
	void narudzba();

	string get_vlasnik();
	void dodaj_vlasnika(Vlasnik* novi_vlasnik);
	/*void dodaj_svinju(string ID, string vrsta, Namjena_svinje namjena, Datum datum_zaprimanja, Datum planirani_datum_klanja, float kilaza, float ciljana_kilaza);
	*/
	/*konstuktor klase*/
	Poduzece(const string& ime, Vrsta_poduzeca vrsta, Vlasnik* vlasnik, Radnik& radnik, Radnici* radnici)
		: ime_poduzeca(ime), vrsta_poduzeca(vrsta), vlasnik(vlasnik), radnik(radnik), radnici(radnici) {};

	void dodaj_Svinju(Svinja* svinja);
};