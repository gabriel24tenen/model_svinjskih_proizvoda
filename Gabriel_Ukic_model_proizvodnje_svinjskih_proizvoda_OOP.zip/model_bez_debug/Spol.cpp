#include "Spol.h"

string Spol::get_naziv() {
	return naziv[s];
}

unsigned short Spol::get_s_no() {
	return s;
}

void Spol::set_naziv(unsigned short new_s) {
	if (new_s > 3)
	{
		cout << "Pogresan naziv spola!" << endl;
		exit(EXIT_FAILURE);
	}
	s = new_s;
}