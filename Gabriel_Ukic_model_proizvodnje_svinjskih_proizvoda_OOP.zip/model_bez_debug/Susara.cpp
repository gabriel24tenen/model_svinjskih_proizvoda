#include "Susara.h"

std::string Susara::get_adresa_susare() {
	return adresa_susare.get_adresa();
}

std::string Susara::get_kapacitet() {
	return to_string(kapacitet) + "jedinica za susenje";
}

void Susara::set_adresa_susare(const string new_ulica, unsigned short new_broj, const string new_grad_opcina, const string new_zupanija, int new_postanski_broj) {
	adresa_susare.set_adresa(new_ulica, new_broj, new_grad_opcina, new_zupanija, new_postanski_broj);
}

void Susara::set_kapacitet(int new_kapacitet) {
	kapacitet = new_kapacitet;
}

void Susara::potreba_susenja(Proizvod* proizvod) {
	bool provjera;
	provjera = proizvod->susenje();
	if (provjera) {
		cout << "Proizvod se stavlja u susaru na susenje" << endl;
		suseni_proizvodi.push_back(proizvod);
	}
	else {
		cout << "Proizvod se stavlja odmah u skladiste" << endl;
		skladiste->dodaj_proizvod(*proizvod);
	}
}