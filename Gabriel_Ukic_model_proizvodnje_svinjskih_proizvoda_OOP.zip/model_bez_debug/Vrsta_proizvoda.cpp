#include "Vrsta_proizvoda.h"

Vrsta_proizvoda::Vrsta_proizvoda() {
	proizvod[0].naziv = "panceta";
	proizvod[0].susenje = true;
	proizvod[0].cijena = 20;
	proizvod[1].naziv = "prsut";
	proizvod[1].susenje = true;
	proizvod[1].cijena = 30;
	proizvod[2].naziv = "plecka";
	proizvod[2].susenje = true;
	proizvod[2].cijena = 15;
	proizvod[3].naziv = "mast";
	proizvod[3].susenje = false;
	proizvod[3].cijena = 4;
	proizvod[4].naziv = "cvarci";
	proizvod[4].susenje = false;
	proizvod[4].cijena = 7;
	proizvod[5].naziv = "suseno meso";
	proizvod[5].susenje = true;
	proizvod[5].cijena = 20;
	proizvod[6].naziv = "kobasice";
	proizvod[6].susenje = true;
	proizvod[6].cijena = 20;
	proizvod[7].naziv = "pecenica";
	proizvod[7].susenje = true;
	proizvod[7].cijena = 25;
	proizvod[8].naziv = "lungic";
	proizvod[8].susenje = false;
	proizvod[8].cijena = 20;
	proizvod[9].naziv = "jetrica";
	proizvod[9].susenje = false;
	proizvod[9].cijena = 5;
	proizvod[10].naziv = "svinjski organi";
	proizvod[10].susenje = false;
	proizvod[10].cijena = 4;
	proizvod[11].naziv = "vratina";
	proizvod[11].susenje = true;
	proizvod[11].cijena = 20;
}

string Vrsta_proizvoda::get_proizvod_name() {
	return proizvod[vp].naziv;
}

bool Vrsta_proizvoda::get_susenje() {
	return proizvod[vp].susenje;
}

unsigned short Vrsta_proizvoda::get_vp_no() {
	return vp;
}

void Vrsta_proizvoda::set_proizvod(unsigned short new_proizvod) {
	if (new_proizvod > 11) {
		cout << "Pogresan proizvod" << endl;
		exit(EXIT_FAILURE);
	}
	vp = new_proizvod;
}

string Vrsta_proizvoda::get_cijena() {
	return to_string(proizvod[vp].cijena);
}