#pragma once
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <string>

using namespace std;

class Vrsta_obrta {
	private:
		const string obrt[4] = { "mesnica", "trgovina", "restoran", "food_fransiza" };
		unsigned short vo;
	public:
		unsigned short get_vo_no();
		void set_obrt(unsigned short new_obrt);
		string get_obrt();
};