#include "Proizvod.h"

void Proizvod::kontrola_svinje(Svinja* svinja)
{
	string kontrola = svinja->get_namjena();
	try {
		if (kontrola == "odojak" || kontrola == "uzgoj" || kontrola == "prodaja")
			throw 1; 
		cout << "Svinja " << svinja->get_ID() <<" je namjenjena za procesuiranje proizvodnje" << endl;
	}
	catch (int n)
	{
		cout << "Namjena svinje "<< svinja->get_ID()<<" nije za procesuiranje proizvodnje!"<<endl;
		cout << "Namjena svinje: " << svinja->get_namjena() << endl;
	}
	catch (const exception& e) {
		cout << "Pogreska!" << endl;
	}
	svinje_proizvodnja.push_back(svinja);
}

Vrsta_proizvoda Proizvod::get_vrsta_proizvoda() {
	return vrsta_proizvoda;
}

void Proizvod::set_vrsta_proizvoda(unsigned short new_vrsta_proizvoda) {
	vrsta_proizvoda.set_proizvod(new_vrsta_proizvoda);
}

string Proizvod::get_datum_proizvodnje() {
	return datum_proizvodnje.get_datum();
}

void Proizvod::set_datum_proizvodnje(string new_datum_proizvodnje) {
	datum_proizvodnje.set_datum(new_datum_proizvodnje);
}

bool Proizvod::susenje() {
	return vrsta_proizvoda.get_susenje();
}

string Proizvod::cijena() {
	return vrsta_proizvoda.get_cijena();
}

list<Svinja*> Proizvod::get_svinje_proizvodnja()
{
	return svinje_proizvodnja;
}
