#include "Poduzece.h"

string Poduzece::get_ime_poduzeca() {
	return ime_poduzeca;
}

string Poduzece::get_vrsta_poduzeca() {
	return vrsta_poduzeca.get_poduzece();
}

void Poduzece::set_ime_poduzeca(string new_ime_poduzeca) {
	ime_poduzeca = new_ime_poduzeca;
}

void Poduzece::set_vrsta_poduzeca(unsigned short new_vrsta_poduzeca) {
	vrsta_poduzeca.set_poduzece(new_vrsta_poduzeca);
}

/*metode*/
void Poduzece::dodaj_dobavljaca(Dobavljac* dobavljac) {
	dobavljaci_poduzeca.push_back(dobavljac);
}

void Poduzece::narudzba_hrane(Dobavljac vrsta_hrane, Dobavljac kolicina) {
	unsigned short vh_no;
	int kol;
	try {
		if (dobavljaci_poduzeca.empty())
			throw 1;
	}
	catch (int n) {
		cout << "Nema dostupnih dobavljaca!" << endl;
		exit(EXIT_FAILURE);
	}
	catch (const exception& e) {
		cout << "Pogreska!" << endl;
		exit(EXIT_FAILURE);
	}
	cout << "Odaberite hranu: \n1- Kukuruz \n2- Zito \n3- Psenica \n4- Mekinje";
	cin >> vh_no;
	vrsta_hrane.set_vrsta_hrane(vh_no);
	cout << "Odaberite kolicinu (u kg): ";
	cin >> kol;
	vrsta_hrane.set_kolicina(kol);
	cout << "Narudzba zaprimljena! " << endl;
}

void Poduzece::dodaj_radnika(string new_radnik) {
	try {
		list<string>::iterator it = radnici_lista.begin();
		list<string>::iterator en = radnici_lista.end();
		while (it != en && *it != new_radnik)
			advance(it, 1);
		if (it != en)
			throw 1;
		radnici_lista.push_back(new_radnik);
	}
	catch (int n)
	{
		cout << "Radnik je vec prijavljen" << endl;
		exit(EXIT_FAILURE);
	}
}

void Poduzece::ukloni_radnika(string new_radnik) {
	list <string>::iterator it = radnici_lista.begin();
	list <string>::iterator en = radnici_lista.end();
	while (it != en && *it != new_radnik)
		advance(it, 1);
	if (it == en) {
		cout << "Radnik nije pronaden" << endl;
		exit(EXIT_FAILURE);
	}
	radnici_lista.erase(it);
}

void Poduzece::ispis_svih_placa()
{
	list<Radnik>& svi_radnici = radnici->lista_radnika();
	for (Radnik& radnik : svi_radnici)
	{
		cout <<" Ime: " << radnik.get_ime() << endl;
		cout << "Prezime: " << radnik.get_prezime() << endl;
		cout << "Broj sati:" << radnik.get_broj_sati() << endl;
		cout << "Satnica: " << radnik.get_satnica() << endl;
		cout << "Placa: " << radnik.obracun_place() <<"eura" << endl;
	}

}

void Poduzece::dodaj_obrtnika(string new_obrtnik) {
	try {
		list<string>::iterator it = obrtnici.begin();
		list<string>::iterator en = obrtnici.end();
		while (it != en && *it != new_obrtnik)
			advance(it, 1);
		if (it != en)
			throw 1;
		obrtnici.push_back(new_obrtnik);
	}
	catch (int n) {
		cout << "Obrtnik je vec unesen" << endl;
		exit(EXIT_FAILURE);
	}
}

void Poduzece::ukloni_obrtnika(string new_obrtnik) {
	list<string>::iterator it = obrtnici.begin();
	list<string>::iterator en = obrtnici.end();
	while (it != en && *it != new_obrtnik)
		advance(it, 1);
	if (it == en) {
		cout << "Obrtnik nije pronaden" << endl;
		exit(EXIT_FAILURE);
	}
	obrtnici.erase(it);
}

string Poduzece::get_vlasnik()
{
	string podaci_vlasnik;
	podaci_vlasnik = vlasnik->get_ime() + " " + vlasnik->get_prezime();
	return podaci_vlasnik;
}

void Poduzece::dodaj_vlasnika(Vlasnik* novi_vlansik) {
	vlasnik = novi_vlansik;
}

void Poduzece::narudzba() {
	string polje[11] = { "panceta", "prsut", "plecka", "cvarci", "suseno meso", "kobasice", "pecenica", "lungic", "jetrica", "svinjski organi", "vratina" };
	cout << "Panceta \nPanceta, osusena : 58 kilograma \nPanceta, rasjecena : 10 kilograma" << endl;
	cout << "Prsut \nPrsut, osuseni : 15 komada(od 7, 5 do 9 kilograma) \nPrsut, rasjeceni : 6 komada(od 7 do 10 kilograma)" << endl;
	cout << "Plecka \nPlecka, osusena : 20 komada(od 5 do 7 kilograma) \nPlecka, rasjecena : 3 komada(od 5 do 7 kilograma)" << endl;
	cout << "Mast: 50 kilograma(dostavlja se u posudama od po 5 kilograma) \nCvarci : 14 kilograma(dostavlja se u paketima od 500 grama)" << endl;
	cout << "Suseno meso \nRebra : 12 kilograma \nManji komadi : 10 kilograma" << endl;
	cout << "Kobasice \nKrvavice : 22 kilograma \nKulenova seka : 40 kilograma \nObicne : 56 kilograma \nKobasice za pecenje : 26 kilograma" << endl;
	cout << "Pecenica : 40 kilograma \nLungic : 20 kilograma \nJetrica : 26 kilograma" << endl;
	cout << "Svinjski organi \nSrce : 12 komada \nBubreg : 16 komada \nZeludac : 20 komada \nCrijeva : 8 kilograma" << endl;
	cout << "Vratina \nVratina, osusena : 24 kilograma \nVratina, rasjecena : 16 kilograma" << endl; 
	ofstream narudzba("narudzba.txt");
	cout << "Odaberite proizvod koji zelite naruciti: "<<endl;
	for (int i = 0; i < 11; i++)
	{
		cout << i << "-" << polje[i] << " ";
	}
	cout << "Ukoliko zelite zavrsiti s narudzbom unesite broj 99" << endl;
	unsigned short pr;
	int kol;
	double cijena, suma=0;
	do{
		cout << "Odabir proizvoda: ";
		cin >> pr;
		if (pr == 99) {
			cout << "Kraj narucivanja..." << endl;
			cout << "Racun sa sadrzajem vase narudzbe biti ce vam poslan. " << endl;
			break;
		}
		cout << "Unesite kolicinu proizvoda("<< polje[pr] << ") u kilogramima: ";
		cin >> kol;
		Proizvod kontrola;
		kontrola.set_vrsta_proizvoda(pr);
		cijena = stod(kontrola.cijena());
		suma += cijena * kol;
		narudzba << polje[pr] << " - " << kol << " kilograma" << endl;
	} while (pr != 99);
	narudzba << "Ukupni iznos vase narudzbe: " << suma << " eura" << endl;
	narudzba << "Vasa narudzba je zaprimljena! \nNakon pregleda narudzbe, dodatno cemo vas kontaktirati ukoliko bude potrebe" << endl;
	narudzba.close();
	cout << "Izradujemo vasu narudzbu..." << endl;
	cout << "Narudzba vam je poslana! Zahvaljujemo vam se na ukazanom povjerenju!" << endl;
}

void Poduzece::dodaj_Svinju(Svinja* svinja) {
	svinje.push_back(svinja);
}