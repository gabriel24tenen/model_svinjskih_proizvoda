#pragma once
#include <iostream>
#include <string>
#include <cstring>
#include "Datum.h"
#include "Adresa.h"
#include "Spol.h" 
#include <vector>
using namespace std;

class Osoba {
protected:
	string ime, prezime, OIB;
	Datum datum_rodenja;
	Adresa adresa_stanovanja;
	Spol spolna_orijentacija;
	vector <string> email;
private:
	unsigned short kontrola_OIB(string k);
	bool email_postojanost(bool p);
public:
	string get_ime();
	string get_datum_rodenja();
	string get_adresa_stanovanja();
	string get_OIB();
	string get_prezime();
	string get_spol();
	string get_email(int k);
	void set_ime(string new_ime);
	void set_datum_rodenja(string new_datum_rodenja);
	void set_OIB(string new_OIB);
	void set_adresa_stanovanja(const string new_ulica, unsigned short new_broj, const string new_grad_opcina, const string new_zupanija, int new_postanski_broj);
	void set_prezime(string new_prezime);
	void set_spol(unsigned short new_spolna_orijentacija);
	void set_email(string new_email);
	void obrisi_mail(int k);
	void promjena_email(int k, string new_email);
};