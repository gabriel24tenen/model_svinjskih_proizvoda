#pragma once
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include "Adresa.h"
#include "Proizvod.h"

using namespace std;

class Skladiste {
	private:
		int kapacitet_hladnjaca;
		Adresa adresa_skladista;
		int kapacitet;
		int kapacitet_frizider;
		vector <Proizvod> proizvodi;
	public:
		string get_kapacitet_hladnjaca();
		string get_kapacitet();
		string get_kapacitet_frizider();
		string get_adresa_skladista();
		void set_kapacitet_hladnjaca(int new_kapacitet_hladnjaca);
		void set_adresa_skladista(const string new_ulica, unsigned short new_broj, const string new_grad_opcina, const string new_zupanija, int new_postanski_broj);
		void set_kapacitet_frizider(int new_kapacitet_frizider);
		void set_kapacitet(int new_kapacitet);
		void dodaj_proizvod(Proizvod& proizvod);
};