#include "Vrsta_hrane.h"

unsigned short Vrsta_hrane::get_vh_no()
{
	return vh;
}

string Vrsta_hrane::get_hrana()
{
	return vrsta[vh];
}

void Vrsta_hrane::set_hrana(unsigned short new_hrana)
{
	if (new_hrana > 3)
	{
		cout << "Pogresno unesena vrsta hrane! " << endl;
		exit(EXIT_FAILURE);
	}
	vh = new_hrana;
}