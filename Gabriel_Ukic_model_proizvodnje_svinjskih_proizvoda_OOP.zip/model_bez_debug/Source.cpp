#include <iostream>
#include <string>
#include <cstring>
#include <ctime>

using namespace std;

string narudzba() {
	string proizvod[5] = { "a", "b", "c", "d", "e" };
	string naruci;
	int izbor;
	do
	{
		int kilaza;
		cout << "------MENU------\n 1 - a\n 2 - b\n 3 - c\n 4 - d\n 5 - e\n 6-izlaz" << endl;
		cout << "Vas izbor: ";
		cin >> izbor;
		switch (izbor) {
		case 1: {
			cout << "Odaberite kilazu: ";
			cin >> kilaza;
			naruci = " " + to_string(kilaza) + "a";
			break;
		}
		case 2: {
			cout << "Odaberite kilazu: ";
			cin >> kilaza;
			naruci = " " + to_string(kilaza) + "b";
			break;
		}
		case 3: {
			cout << "Odaberite kilazu: ";
			cin >> kilaza;
			naruci = " " + to_string(kilaza) + "c";
			break;
		}
		case 4: {
			cout << "Odaberite kilazu: ";
			cin >> kilaza;
			naruci = " " + to_string(kilaza) + "d";
			break;
		}
		case 5: {
			cout << "Odaberite kilazu: ";
			cin >> kilaza;
			naruci = " " + to_string(kilaza) + "e";
			break;
		}
		case 6: cout << "Izlazim iz programa..." << endl; break;
		default: cout << "Pogresan unos!" << endl; break;
		}
	} while (izbor != 6);
	return naruci;
}