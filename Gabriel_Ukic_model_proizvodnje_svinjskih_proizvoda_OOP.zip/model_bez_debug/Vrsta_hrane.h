#pragma once
#include <iostream>
#include <string>
#include <cstring>

using namespace std;

class Vrsta_hrane {
	private:
		const string vrsta[4] = { "kukuruz", "zito", "psenica", "mekinje" };
		unsigned short vh;
	public:
		unsigned short get_vh_no();
		void set_hrana(unsigned short new_hrana);
		string get_hrana();
};