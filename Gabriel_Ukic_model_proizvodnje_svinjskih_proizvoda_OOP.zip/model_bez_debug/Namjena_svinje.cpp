#include "Namjena_svinje.h"

unsigned short Namjena_svinje::get_ns_no()
{
	return ns;
}

string Namjena_svinje::get_namjena()
{
	return namjena[ns];
}

void Namjena_svinje::set_namjena(unsigned short new_namjena)
{
	if (new_namjena > 4)
	{
		cout << "Pogresno unesena namjena svinje! " << endl;
		exit(EXIT_FAILURE);
	}
	ns = new_namjena;
}