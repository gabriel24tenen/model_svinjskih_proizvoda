#pragma once
#include <iostream>
#include <string>
#include <cstring>

using namespace std;

class Vrsta_proizvoda {
	private:
		struct {
			string naziv;
			bool susenje;
			unsigned short cijena;
		}proizvod[12];
		unsigned short vp;
	public:
		Vrsta_proizvoda();
		string get_proizvod_name();
		bool get_susenje();
		unsigned short get_vp_no();
		void set_proizvod(unsigned short new_proizvod);
		string get_cijena();
};