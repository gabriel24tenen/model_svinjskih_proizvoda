#include "Vlasnik.h"

string Vlasnik::get_datum_vlasnistva() {
	return datum_vlasnistva.get_datum();
}

void  Vlasnik::set_datum_vlasnistva(string new_datum_vlasnistva) {
	datum_vlasnistva.set_datum(new_datum_vlasnistva);
}

