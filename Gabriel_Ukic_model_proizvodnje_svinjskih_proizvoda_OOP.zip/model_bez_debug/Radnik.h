#pragma once
#include "Osoba.h"
#include "Radno_mjesto.h"
#include "Radnici.h"
#include "Datum.h"
#include <fstream>

using namespace std;

class Radnik : public Osoba {
	friend class Radnici;
	private:
		Datum datum_zaposlenja;
		Radno_mjesto mjesto_rada;
		float satnica;
		unsigned int broj_sati;
	public:
		string get_datum_zaposlenja();
		string get_mjesto_rada();
		string get_satnica();
		string get_broj_sati();
		void set_datum_zaposlenja(string new_datum_zaposlenja);
		void set_mjesto_rada(unsigned short new_mjesto_rada);
		void set_satnica(float new_satnica);
		void set_broj_sati(unsigned int new_broj_sati);
		double obracun_place();
		void ispis_place();
		Radnik(Datum datum_zaposlenja,Radno_mjesto mjesto_rada, float satnica, unsigned int broj_sati)
			: datum_zaposlenja(datum_zaposlenja), mjesto_rada(mjesto_rada), satnica(satnica), broj_sati(broj_sati) {}
};