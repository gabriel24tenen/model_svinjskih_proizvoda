#pragma once
#include <iostream>
#include <string>
#include <cstring>
#include "Datum.h"
#include "Adresa.h"
#include "Namjena_svinje.h"
#include "Svinjar.h"

using namespace std;

class Svinjar;
class Svinja {
	private:
		string ID;
		string vrsta;
		Namjena_svinje namjena;
		Datum datum_zaprimanja, planirani_datum_klanja;
		float kilaza, ciljana_kilaza;
		Svinjar* svinjar;
		float kilaza_provjera(float kil);
	public:
		string get_ID();
		string get_vrsta();
		string get_namjena();
		string get_datum_zaprimanja();
		string get_planirani_datum_klanja();
		float get_kilaza();
		float get_ciljana_kilaza();
		Svinjar* get_svinjar();
		void set_ID(string new_ID);
		void set_vrsta(string new_vrsta);
		void set_namjena(unsigned short new_namjena);
		void set_datum_zaprimanja(string new_datum_zaprimanja);
		void set_planirani_datum_klanja(string new_planirani_datum_klanja);
		void set_kilaza(float new_kilaza);
		void set_ciljana_kilaza(float new_ciljana_kilaza);
		void set_svinjar(Svinjar* new_svinjar);
		void klanje(string danas, Datum planirani_datum_klanja);
};