#include "Radno_mjesto.h"

string Radno_mjesto::get_vrsta() {
	return vrsta[rm];
}

unsigned short Radno_mjesto::get_vrsta_no() {
	return rm;
}

void Radno_mjesto::set_vrsta(unsigned short new_vrsta) {
	if (new_vrsta > 4)
	{
		cout << "Pogresno uneseno radno mjesto! " << endl;
		exit(EXIT_FAILURE);
	}
	rm = new_vrsta;
}