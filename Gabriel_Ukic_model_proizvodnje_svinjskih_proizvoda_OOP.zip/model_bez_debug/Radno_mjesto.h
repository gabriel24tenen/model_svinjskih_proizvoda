#pragma once
#include <iostream>
#include <cstring>
#include <string>
#include <cstdlib>

using namespace std;

class Radno_mjesto {
private:
	const string vrsta[5] = { "hranitelj", "koljac", "susar", "skladistar", "distributer" };
	unsigned short rm;
public:
	string get_vrsta();
	void set_vrsta(unsigned short new_vrsta);
	unsigned short get_vrsta_no();
};