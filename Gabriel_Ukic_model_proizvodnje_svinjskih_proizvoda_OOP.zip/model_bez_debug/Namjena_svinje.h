#pragma once
#include <iostream>
#include <string>
#include <cstring>

using namespace std;

class Namjena_svinje {
private:
	const string namjena[5] = { "mesnica", "odojak", "proizvodnja", "prodaja", "uzgoj" };
	unsigned short ns;
public:
	unsigned short get_ns_no();
	void set_namjena(unsigned short new_namjena);
	string get_namjena();
};