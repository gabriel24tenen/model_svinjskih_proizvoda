#include "Adresa.h"

std::string Adresa::get_adresa() {
	return ulica + " " + std::to_string(broj) + grad_opcina + ", " + zupanija + ", " + std::to_string(postanski_broj);
}

std::string Adresa::get_grad_opcina() {
	return grad_opcina;
}

std::string Adresa::get_ulica() {
	return ulica;
}

std::string Adresa::get_zupanija() {
	return zupanija;
}

std::string Adresa::get_broj() {
	return std::to_string(broj);
}

std::string Adresa::get_postanski_broj() {
	return std::to_string(postanski_broj);
}

int Adresa::kontrola_pbr(int pbr) {
	try {
		if (pbr < 10000 || pbr > 99999)
			throw 1;
		return pbr;
	}
	catch (int n) {
		cout << "Pogresno unesen postanski broj! Broj nije peteroznamenkast" << endl;
		exit(EXIT_FAILURE);
	}
	catch (const invalid_argument& ai) {
		cout << "Pogresno unesen postanski broj" << endl;
		exit(EXIT_FAILURE);
	}
}
bool Adresa::RH(string cro) {
	string county[21] = { "Dubrova�ko-neretvanska", "Splitsko-dalmatinska", "�ibensko-kninska", "Zadarska", "Li�ko-senjska", "Istarska", "Primorsko-goranska", "Karlova�ka",
	"Sisa�ko-moslava�ka", "Zagreba�ka", "Grad Zagreb", "Krapinsko-zagorska", "Vara�dinska", "Me�imurska", "Bjelovarsko-bilogorska", "Koprivni�ko-kri�eva�ka", "Osje�ko-baranjska",
	"Vukovarsko-srijemska", "Brodsko-posavska", "Po�e�ko-slavonska", "Virovit�ko-podravska"};
	string kontrola = Adresa::get_zupanija();
	unsigned short k = 0;
	try {
		for (int i = 0; i <= 20; i++)
		{
			if (kontrola == county[i])
			{
				k = 1;
				break;
			}
		}
	}
	catch (const std::invalid_argument &ai){
		cout << "Pogresno unesena �upanija" << endl;
		exit(EXIT_FAILURE);
	}
	if (k == 0)
	{
		cout << "Adresa se nalazi izvan Republike Hrvatske" << endl;
		return false;
	}
	return true;
}

void Adresa::set_grad_opcina(string new_grad_opcina) {
	grad_opcina = new_grad_opcina;
}

void Adresa::set_ulica(string new_ulica) {
	ulica = new_ulica;
}

void Adresa::set_zupanija(string new_zupanija) {
	zupanija = new_zupanija;
	Adresa::RH(new_zupanija);
}

void Adresa::set_broj(unsigned short new_broj) {
	broj = new_broj;
}

void Adresa::set_postanskibroj(int new_postanski_broj) {
	try {
		unsigned short k = kontrola_pbr(new_postanski_broj);
		if (new_postanski_broj > 53291)
			throw 1;
		postanski_broj = new_postanski_broj;
	}
	catch (int i) {
		cout << "Pogresan po�tanski broj! Izvan raspona postanskih brojeva unutar Republike Hrvatske" << endl;
		exit(EXIT_FAILURE);
	}
	catch (std::exception& e) {
		cout << "Pogre�an po�tanski broj!" << endl;
		exit(EXIT_FAILURE);
	}
}

void Adresa::set_adresa(const string new_ulica, unsigned short new_broj, const string new_grad_opcina, const string new_zupanija, int new_postanski_broj)
{
	set_ulica(new_ulica);
    set_broj(new_broj);
    set_grad_opcina(new_grad_opcina);
    set_zupanija(new_zupanija);
    set_postanskibroj(new_postanski_broj);
    adress = get_adresa();
}
