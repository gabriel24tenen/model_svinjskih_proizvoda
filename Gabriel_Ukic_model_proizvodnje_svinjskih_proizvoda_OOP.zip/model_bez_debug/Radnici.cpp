#include "Radnici.h"

Radnik* Radnici::get_radnik(unsigned int i) {
	if (i >= svi_radnici.size()) {
		cout << "Redni broj koji ste unijeli je premasio velicinu liste" << endl;
		exit(EXIT_FAILURE);
	}
	list<Radnik>::iterator it = svi_radnici.begin();
	advance(it, i);
	return &(*it);
}

void Radnici::set_radnik(Radnik new_radnik) {
	svi_radnici.push_back(new_radnik);
}

void Radnici::import_radnici(const char* popis_radnika) {
	ifstream file(popis_radnika);
	string opis;
	Datum datum_zaposlenja{};
	Radno_mjesto mjesto_rada{};
	float satnica{};
	unsigned int broj_sati{};
	while (getline(file, opis)) {
		Radnik novi(datum_zaposlenja, mjesto_rada, satnica, broj_sati);
		set_radnik(novi);
	}
	file.close();
}

void Radnici::export_radnici(const char* popis_radnika) {
	ofstream file(popis_radnika);
	string opis;
	unsigned int broj;
	cout << "Unesite redni broj radnika";
	cin >> broj;
	Radnik* rad = get_radnik(broj);
	file << "Informacije o radniku: " << endl;
	file << "Ime: " << rad->get_ime() << endl;
	file << "Prezime: " << rad->get_prezime() << endl;
	file << "OIB: " << rad->get_OIB() << endl;
	file << "Datum rodenja: " << rad->get_datum_rodenja() << endl;
	file << "Datum zaposlenja: " << rad->get_datum_zaposlenja() << endl;
	file << "Mjesto rada: " << rad->get_mjesto_rada() << endl;
	file << "Satnica: " << rad->get_satnica() << endl;
	file << "Broj sati: " << rad->get_broj_sati() << endl;
	file << "Placa za ovaj mjesec(u eurima): " << rad->obracun_place() << endl;
	file.close();
}

list <Radnik>& Radnici::lista_radnika() {
	return svi_radnici;
}