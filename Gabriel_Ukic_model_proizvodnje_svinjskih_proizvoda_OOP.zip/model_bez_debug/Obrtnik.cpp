#include "Obrtnik.h"

string Obrtnik::get_adresa_obrta() {
	return adresa_obrta.get_adresa();
}

string Obrtnik::get_vrsta_obrta() {
	return vrsta_obrta.get_obrt();
}

string Obrtnik::get_naziv_obrta() {
	return naziv_obrta;
}

void Obrtnik::set_adresa_obrta(const string new_ulica, unsigned short new_broj, const string new_grad_opcina, const string new_zupanija, int new_postanski_broj) {
	adresa_obrta.set_adresa(new_ulica, new_broj, new_grad_opcina, new_zupanija, new_postanski_broj);
}

void Obrtnik::set_vrsta_obrta(unsigned short new_vrsta_obrta) {
	vrsta_obrta.set_obrt(new_vrsta_obrta);
}

void Obrtnik::set_naziv_obrta(string new_naziv_obrta) {
	naziv_obrta = new_naziv_obrta;
}

void Obrtnik::napravi_narudzbu()
{
	poduzece->narudzba();
}
