#include "Vrsta_obrta.h"

unsigned short Vrsta_obrta::get_vo_no() {
	return vo;
}

void Vrsta_obrta::set_obrt(unsigned short new_obrt) {
	if (new_obrt > 3)
	{
		cout << "Pogresno unesena vrsta obrta" << endl;
		exit(EXIT_FAILURE);
	}
	vo = new_obrt;
}

string Vrsta_obrta::get_obrt() {
	return obrt[vo];
}