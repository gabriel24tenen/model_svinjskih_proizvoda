#include "Osoba.h"

string Osoba::get_ime() {
	return ime;
}

string Osoba::get_prezime() {
	return prezime;
}

string Osoba::get_OIB() {
	return OIB;
}

string Osoba::get_spol() {
	return spolna_orijentacija.get_naziv();
}

string Osoba::get_datum_rodenja() {
	return datum_rodenja.get_datum();
}

string Osoba::get_adresa_stanovanja() {
	return adresa_stanovanja.get_adresa();
}

string Osoba::get_email(int k) {
	if (k >= email.size())
		return "";
	else
		return email[k];
}

void Osoba::set_ime(string new_ime) {
	ime = new_ime;
}

void Osoba::set_prezime(string new_prezime) {
	prezime = new_prezime;
}

void Osoba::set_OIB(string new_OIB) {
	try {
		unsigned short k = kontrola_OIB(new_OIB.substr(0, 10));
		if (new_OIB.size() != 11 || k != stoi(new_OIB.substr(10, 1)))
			throw 1;
		OIB = new_OIB;
	}
	catch (int n) {
		cout << "Pogresan OIB! " << endl;
		exit(EXIT_FAILURE);
	}
	catch (exception& e) {
		cout <<"Pogresan OIB! " << endl;
			exit(EXIT_FAILURE);
	}
}

void Osoba::set_adresa_stanovanja(const string new_ulica, unsigned short new_broj, const string new_grad_opcina, const string new_zupanija, int new_postanski_broj) {
	adresa_stanovanja.set_adresa(new_ulica, new_broj, new_grad_opcina, new_zupanija, new_postanski_broj);
}

void Osoba::set_datum_rodenja(string new_datum_rodenja) {
	datum_rodenja.set_datum(new_datum_rodenja);
}

void Osoba::set_spol(unsigned short new_spolna_orijentacija) {
	spolna_orijentacija.set_naziv(new_spolna_orijentacija);
}

void Osoba::set_email(string new_email) {
	email.push_back(new_email);
}

void Osoba::obrisi_mail(int k) {
	if (k >= email.size()) {
		cout << "Nepostojeca email adresa! " << endl;
		exit(EXIT_FAILURE);
	}
	else
	{
		vector <string>::iterator it;
		it = email.begin();
		email.erase(it + k);
	}
}

void Osoba::promjena_email(int k, string new_email) {
	if (k >= email.size()) {
		cout << "Nepostojeca email adresa! " << endl;
		exit(EXIT_FAILURE);
	}
	else
		email[k] = new_email;
}

unsigned short Osoba::kontrola_OIB(string k) {
	try {
		if (k.length() != 10)
			throw 1;
		int kontrola = 10;
		for (int i = 0; i < 10; i++) {
			kontrola += stoi(k.substr(i, 1));
			kontrola %= 10;
			if (kontrola == 0)
				kontrola = 10;
			kontrola *= 2;
			kontrola %= 11;
		}
		kontrola = 11 - kontrola;
		if (kontrola == 10)
			kontrola = 0;
		return kontrola;
	}
	catch (int n) {
		cout << "Pogresan OIB! " << endl;
		exit(EXIT_FAILURE);
	}
	catch (const invalid_argument& ai) {
		cout << "Pogresan OIB! " << endl;
		exit(EXIT_FAILURE);
	}
}

bool Osoba::email_postojanost(bool p) {
	p = false;
	if (email.size() == 0)
		cout << "Email nije unesen" << endl;
	else p = true;
	return p;
}