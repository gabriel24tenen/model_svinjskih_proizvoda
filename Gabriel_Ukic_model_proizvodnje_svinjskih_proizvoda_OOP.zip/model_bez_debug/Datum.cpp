#include "Datum.h"

std::string Datum::get_datum() {
	return std::to_string(dan) + "." + std::to_string(mjesec) + "." + std::to_string(godina) + ".";
}

bool Datum::kontrola(std::string str) {
	unsigned short broj_dana[] = { 31,29,31,30,31,30,31,31,30,31,30,31 };
	unsigned short day, month, year;
	try {
		day = stoi(str.substr(0, 2));
		month = stoi(str.substr(3, 2));
		year = stoi(str.substr(6, 4));
	}
	catch (const std::invalid_argument& ai) {
		return false;
	}
	if (month < 1 || month > 12)
		return false;
	if (day < 1 || day > broj_dana[month - 1])
		return false;
	return true;
}

void Datum::set_datum(std::string new_datum) {
	try {
		if (!kontrola(new_datum)) throw 1;
		dan = stoi(new_datum.substr(0, 2));
		mjesec = stoi(new_datum.substr(3, 2));
		godina = stoi(new_datum.substr(6, 4));
	}
	catch (int n) {
		std::cout << "Pogresan datum" << std::endl;
		exit(EXIT_FAILURE);
	}
}

unsigned short Datum::broj_godina() {
	time_t* t = new time_t;
	*t = time(NULL);
	tm* dat = gmtime(t);
	unsigned short s = dat->tm_year - godina + 1899;
	if (mjesec < dat->tm_mon + 1 || mjesec == dat->tm_mon + 1 && dan <= dat->tm_mday)
		s++;
	return s;
}