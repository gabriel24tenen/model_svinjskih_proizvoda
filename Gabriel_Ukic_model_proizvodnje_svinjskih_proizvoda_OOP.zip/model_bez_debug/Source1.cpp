/*#include "Osoba.h"
#include "Svinja.h"
#include <fstream>

using namespace std;

void funkcija(Svinja new_svinja){
	string new_ID, new_vrsta;
	float new_kilaza, new_ciljana_kilaza;
	string new_dzpr, new_pdkl;
	unsigned short new_namjena;
	fstream dat;
	cout << "Unesite ID svinje: ";
	new_svinja.set_ID(new_ID);
	cout << "Unesite vrstu svinje: ";
	new_svinja.set_vrsta(new_vrsta);
	cout << "Unesite trenutnu kilazu: ";
	new_svinja.set_kilaza(new_kilaza);
	cout << "Unesite ciljanu kilazu koju zelite da svinja postigne: ";
	new_svinja.set_ciljana_kilaza(new_ciljana_kilaza);
	cout << "Unesite datum zaprimanja: ";
	new_svinja.set_datum_zaprimanja(new_dzpr);
	cout << "Unesite planirani datum klanja: ";
	new_svinja.set_planirani_datum_klanja(new_pdkl);
	cout << "Unesite koju namjenu ima vasa svinja: ";
	new_svinja.set_namjena(new_namjena);
	dat.open("prijava.txt", ios::in | ios::out);
		cout << "ID: " << new_svinja.get_ID();
		cout << "Vrsta: " << new_svinja.get_vrsta();
		cout << "Kilaza: " << new_svinja.get_kilaza();
		cout << "Ciljana kilaza: " << new_svinja.get_ciljana_kilaza();
		cout << "Datum zaprimanja: " << new_svinja.get_datum_zaprimanja();
		cout << "Planirani datum klanja: " << new_svinja.get_planirani_datum_klanja();
		cout << "Namjena: " << new_svinja.get_namjena();
		dat.close();
}

int main() {

}*/