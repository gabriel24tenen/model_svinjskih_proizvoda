#pragma once
#include <iostream>
#include <string>
#include <cstring>
#include <list>
#include <vector>
#include "Datum.h"
#include "Adresa.h"
#include "Svinja.h"

using namespace std;

class Svinja;

class Svinjar {
private:
	unsigned int velicina;
	unsigned short kapacitet;
	Adresa adresa_svinjara;
	Datum datum_izgradnje, datum_ciscenja;
	list <Svinja*> svinje_svinjar;
public:
	unsigned int get_velicina();
	unsigned short get_kapacitet();
	string get_adresa_svinjara();
	string get_datum_izgradnje();
	string get_datum_ciscenja();
	void set_velicina(unsigned int new_velicina);
	void set_kapacitet(unsigned short new_kapacitet);
	void set_adresa_svinjara(const string new_ulica, unsigned short new_broj, const string new_grad_opcina, const string new_zupanija, int new_postanski_broj);
	void set_datum_izgradnje(string new_datum_izgradnje);
	void set_datum_ciscenja(string new_datum_ciscenja);
	Svinjar(const unsigned short kapacitet, const unsigned short velicina, const Datum datum_izgradnje, const Datum planirani_datum_ciscenja, const Adresa adresa);
	list <Svinja*> get_svinje();
	void dodaj_svinju_svinjar(Svinja* svinja, Svinjar* svinjar);
	void ciscenje(string danas, Datum datum_ciscenja);
};