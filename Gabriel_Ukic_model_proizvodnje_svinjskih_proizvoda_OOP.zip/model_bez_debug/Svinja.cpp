#include "Svinja.h"

float Svinja::kilaza_provjera(float kil) {
	try {
		if (kil < 0)
			throw 1;
		return kil;
	}
	catch (int n) {
		cout << "Kilaza nije moguca! Unesena vrijednost je manja od nule" << endl;
		exit(EXIT_FAILURE);
	}
	catch (const invalid_argument& ai) {
		cout << "Pogresno unesena kilaza" << endl;
		exit(EXIT_FAILURE);
	}
}

void Svinja::klanje(string danas,Datum planirani_datum_klanja)
{
	Datum datum;
	datum.set_datum(danas);
	unsigned short dan = stoi(danas.substr(0, 2));
	unsigned short mjesec = stoi(danas.substr(3, 2));
	unsigned short godina = stoi(danas.substr(6, 4));
	string klanje = planirani_datum_klanja.get_datum();
	unsigned short pdk_dan = stoi(klanje.substr(0, 2));
	unsigned short pdk_mjesec = stoi(klanje.substr(3, 2));
	unsigned short pdk_godina = stoi(klanje.substr(6, 4));
	if (pdk_godina == godina && pdk_mjesec == mjesec && pdk_dan == dan)
		cout << "Datum klanja svinje je danas" << endl;
	else if (pdk_godina > godina || (pdk_godina == godina && pdk_mjesec > mjesec) || (pdk_godina == godina && pdk_mjesec == mjesec && pdk_dan > dan))
		cout << "Svinja jos nije spremna za klanje" << endl;
	else cout << "Datum klanja svinje je prosao!" << endl;
}


string Svinja::get_ID() {
	return ID;
}

string Svinja::get_vrsta() {
	return vrsta;
}

string Svinja::get_namjena() {
	return namjena.get_namjena();
}

string Svinja::get_datum_zaprimanja() {
	return datum_zaprimanja.get_datum();
}

string Svinja::get_planirani_datum_klanja() {
	return planirani_datum_klanja.get_datum();
}

float Svinja::get_kilaza() {
	return kilaza;
}

float Svinja::get_ciljana_kilaza() {
	return ciljana_kilaza;
}

Svinjar* Svinja::get_svinjar() {
	return svinjar;
}

void Svinja::set_ID(string new_ID) {
	ID = new_ID;
}

void Svinja::set_vrsta(string new_vrsta) {
	vrsta = new_vrsta;
}

void Svinja::set_namjena(unsigned short new_namjena) {
	namjena.set_namjena(new_namjena);
}

void Svinja::set_datum_zaprimanja(string new_datum_zaprimanja) {
	datum_zaprimanja.set_datum(new_datum_zaprimanja);
}

void Svinja::set_planirani_datum_klanja(string new_planirani_datum_klanja) {
	planirani_datum_klanja.set_datum(new_planirani_datum_klanja);
}

void Svinja::set_kilaza(float new_kilaza) {
	try {
		float kontrola = kilaza_provjera(new_kilaza);
		kilaza = new_kilaza;
	}
	catch (int n) {
		cout << "Pogresno unesena kilaza!" << endl;
	}
	catch (std::exception& e) {
		cout << "Pogre�no unesena kilaza!" << endl;
		exit(EXIT_FAILURE);
	}
}

void Svinja::set_ciljana_kilaza(float new_ciljana_kilaza) {
	try {
		float kontrola = kilaza_provjera(new_ciljana_kilaza);
		ciljana_kilaza = new_ciljana_kilaza;

	}
	catch (int n) {
		cout << "Pogresno unesena kilaza!" << endl;
	}
	catch (std::exception& e) {
		cout << "Pogre�no unesena kilaza!" << endl;
		exit(EXIT_FAILURE);
	}
}

void Svinja::set_svinjar(Svinjar* new_svinjar) {
	svinjar = new_svinjar;
}

