#include "Dobavljac.h"

string Dobavljac::get_vrsta_hrane() {
	return vrsta_hrane.get_hrana();
}

string Dobavljac::get_kolicina() {
	return to_string(kolicina);
}

void Dobavljac::set_kolicina(int new_kolicina) {
	kolicina = new_kolicina;
}

void Dobavljac::set_vrsta_hrane(unsigned short new_vrsta_hrane) {
	vrsta_hrane.set_hrana(new_vrsta_hrane);
}