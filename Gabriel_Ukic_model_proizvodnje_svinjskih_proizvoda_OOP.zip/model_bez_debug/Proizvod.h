#pragma once
#include "Svinja.h"
#include "Vrsta_proizvoda.h"
#include <list>

using namespace std;

class Proizvod {
	private:
		Vrsta_proizvoda vrsta_proizvoda;
		Datum datum_proizvodnje;
		list <Svinja*> svinje_proizvodnja;

	public:
		Vrsta_proizvoda get_vrsta_proizvoda();
		void set_vrsta_proizvoda(unsigned short new_vrsta_proizvoda);
		string get_datum_proizvodnje();
		void set_datum_proizvodnje(string new_datum_proizvodnje);
		bool susenje();
		string cijena();
		list <Svinja*> get_svinje_proizvodnja();
		void kontrola_svinje(Svinja* svinja);
};