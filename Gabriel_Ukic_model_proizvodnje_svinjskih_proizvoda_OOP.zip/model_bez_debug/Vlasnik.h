#pragma once
#include "Osoba.h"

using namespace std;

class Vlasnik : public Osoba {
	private:
		Datum datum_vlasnistva;
	public:
		string get_datum_vlasnistva();
		void set_datum_vlasnistva(string new_datum_vlasnistva);
};