#pragma once
#include <iostream>
#include <string>
#include <cstring>

using namespace std;

class Vrsta_poduzeca {
	private:
		const string poduzece[5] = { "jdoo", "opg", "obrt", "dd", "doo" };
		unsigned short vp;
	public:
		unsigned short get_vp_no();
		void set_poduzece(unsigned short new_poduzece);
		string get_poduzece();
};